// VARIABLE yg bisa di pakai
/*
{USER}
{WAKTU}
{TANGGAL}
{USERTAG}
{UCAPAN} 
{GRUBNAME}

*/




// TEMPLATE VERSI 1
/* 
const awalanItem = '» ';
const template_list = `{UCAPAN} {USERTAG}

📝 {GRUBNAME}
⏳ {WAKTU} WIB
📆 {TANGGAL}

*⬇️ List Menu ⬇️*

{LIST_ITEMS}

Untuk Melihat List menu
Ketik *teks* di atas`;
*/





// TEMPLATE VERSI 2
const awalanItem = '│𝆹ׁ𝅥𝆺𝅥  ۪ │𓈒';
const template_list = ` ᕱ ⑅ ᕱ   ۪ 𝅄 ۫ ׅ  📜 ֗  ֹ۪  ༝ 𝆹𝅥  ݊    𖤳    ֹ ۪ 𓈒
૮Ꮚ ´‌  ⁄ ⁄   '‌꒱ *{UCAPAN} {USERTAG} 𝐁ꫀrꪱkυt 𝐃ɑftɑr Menu 𝐋ꪱst {GRUBNAME}*
┌ ۫  𝆭   ׁ ┐⊱  ׁ ꒰ ─ׁ─┄┄┄۪݊┄┄ིׅ┄ྀ┄──֢ ꒱

{LIST_ITEMS}
╰┈┈❀ ֹ⭒  ִֶָ  ࣪  *Ⓒ. 𝕭ryb𐐫‌ȶ ²⁰²¹*  ׁ ׅ  𝅭 ˖

Untuk Melihat List Ketik *teks diatas* contoh *Free Fire* `;
module.exports = {
    awalanItem,
    template_list
};
