const listsewa_ = `¥ Price Sewa Bot Brypay €

🔏 1 bulan   = 10k
🔏 2 bulan  = 18k
🔏 jadibot = 30k/bulan

Untuk Melanjutkan Sewa Silahkan Hubungi 085854501918`;

module.exports = {
    listsewa_
};
